calibrateRef<-function(x,ppm1,ppm2){
#function to align spectra according to a singlet
#ppm1, ppm2 left and right margins of the region containing 
#the spectral reference (ex. TSP, DSS, glucose...), respectively
#written by Gon?��alo Gra?��a, ITQB-UNL Portugal, ggraca@itqb.unl.pt
#modified by Jie Hao, Imperial College London.
if (ppm2<ppm1) 
{
ppm3 <- ppm2
ppm2 <- ppm1
ppm1 <- ppm3
}
int <- which(x[,1]<ppm2 & x[,1]>ppm1)
ind<-apply(x[int,2:dim(x)[2]],2,which.max)
med<-floor(median(ind))
d<-as.numeric(lapply(ind,function(x) x-med))
n<-dim(x)[1]
p<-dim(x)[2]
M<-matrix(rep(NA,times=n*p) , nrow = n)
colnames(M)<-colnames(x)
M[,1]<-x[,1]
	for (i in 1:length(d)){
		if (d[i] == 0){
		M[,i+1]<-x[,i+1]
		} else if (d[i] < 0){
		M[,i+1]<-c(rep(0,times=abs(d[i])),x[1:(dim(x)[1]-abs(d[i])),i+1])
		} else if (d[i] > 0){
		M[,i+1]<-c(x[(d[i]+1):(dim(x)[1]),i+1],rep(0,times=abs(d[i])))
		}
	}
return(M)}
